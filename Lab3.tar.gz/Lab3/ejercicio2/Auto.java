public class Auto {

     private  String marca;
     private  int capacidad_estanque;
     private  int kilometraje;
     private boolean estado;

     public Auto (String marca, int capacidad_estanque,boolean estado){
         this.marca= marca;
         this.capacidad_estanque = capacidad_estanque;
         this.kilometraje = (int)((Math.random()*2000) + 1);
         this.estado = estado;
     }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getCapacidad_estanque() {
        return capacidad_estanque;
    }

    public void setCapacidad_estanque(int capacidad_estanque) {
        this.capacidad_estanque = capacidad_estanque;
    }

    public int getKilometraje() {
        return kilometraje;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
}
