import java.util.ArrayList;
public class Estacionamiento {

    private int capacidad_estacionamiento = 10;
    private ArrayList <Auto> listaautosestacionados;

    public Estacionamiento( ArrayList<Auto> listaautosestacionados) {
        this.capacidad_estacionamiento = capacidad_estacionamiento;
        this.listaautosestacionados = listaautosestacionados;
    }

    public int getCapacidad_estacionamiento() {
        return capacidad_estacionamiento;
    }

    public void setCapacidad_estacionamiento(int capacidad_estacionamiento) {
        this.capacidad_estacionamiento = capacidad_estacionamiento;
    }

    public ArrayList<Auto> getListaautosestacionados() {
        return listaautosestacionados;
    }

    public void setListaautosestacionados(ArrayList<Auto> listaautosestacionados) {
        this.listaautosestacionados = listaautosestacionados;
    }
}
