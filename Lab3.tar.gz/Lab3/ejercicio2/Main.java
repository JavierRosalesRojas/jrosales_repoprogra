import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main (String[] args) {


        //ArrayList<Auto> list1 = new ArrayList<Auto>();
        //Estacionamiento est = new Estacionamiento(list1);

        ArrayList<Auto> list1 = new ArrayList<Auto>();
        Estacionamiento est = new Estacionamiento(list1);
        int i = 0;
        int opcion = 0;

        for (i = 0; i < 10; i++) {
            opcion = (int) ((Math.random() * 3) + 1);
            if (opcion == 1) {
                list1.add(new Auto("Peugeot", 40, true));
            }
            if (opcion == 2) {
                list1.add(new Auto("Mazda 2", 20, true));

            }
            if (opcion == 3) {
                list1.add(new Auto("Jeep Full", 60, true));

            }
        }

        int escoger = 0;
        System.out.println("Escoja un automovil: ");
        for (Auto x : list1) {
            if (x.isEstado()) {
                escoger++;
                System.out.print(escoger + " ");
                System.out.println(x.getMarca() + ", Capacidad estanque :" + x.getCapacidad_estanque() + ", Kilometraje :" + x.getKilometraje());
            }
        }

        Scanner escoges = new Scanner(System.in);
        escoger = escoges.nextInt();
        list1.get(escoger - 1);
        Auto a = list1.get(escoger - 1);
        list1.get(escoger - 1).setEstado(false);
        System.out.println("El auto escogido es : " + a.getMarca() + ", Capacidad estanque :" + a.getCapacidad_estanque() + ", Kilometraje :" + a.getKilometraje());

        int y = 0;
        System.out.println("Escoja un automovil: ");
        for (Auto x : list1) {
            if (x.isEstado()) {
                y++;
                System.out.print(y + " ");
                System.out.println(x.getMarca() + ", Capacidad estanque :" + x.getCapacidad_estanque() + ", Kilometraje :" + x.getKilometraje());
            }
        }
    }



}
