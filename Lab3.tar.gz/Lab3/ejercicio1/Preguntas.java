public class Preguntas {
    String pregunta;
    int puntaje;

    Preguntas (String pregunta)
    {
        this.pregunta=pregunta;
        puntaje = 25;

    }
}
