import java.util.Scanner;
import java.util.ArrayList;

public class Prueba {

    public void prueba (){

        Scanner entradasacanner = new Scanner(System.in);
        int [] seleccionar = new int[5];
        ArrayList<Preguntas> prueba = new ArrayList<Preguntas>();

        int seleccionar_pregunta;
        int total;
        String pregunta;

        System.out.println("Ingre la cantidad de preguntas que desea para su prueba :");
        total = entradasacanner.nextInt();

        while (total < 5)
        {
            System.out.println("Ingrese al menos 5 preguntas :");
            total = entradasacanner.nextInt();
        }
        entradasacanner.nextLine();
        for (int i = 0; i<total; i=i+1)
        {
            System.out.println("Ingrese la Pregunta : ");
            pregunta = entradasacanner.nextLine();
            Preguntas preguntas = new Preguntas (pregunta);
            prueba.add(preguntas);

        }
        for (int i=0; i<5; i=i+1)
        {
            System.out.println("Que preguntas va a seleccionar : ");
            seleccionar_pregunta = entradasacanner.nextInt();
            seleccionar[i] = seleccionar_pregunta;

        }
        for (int i=0; i<5; i=i+1)
        {
            System.out.println("PRUEBA");
            System.out.println("preguntas seleccionadas :" + prueba.get(seleccionar[i]).pregunta);
            System.out.println("Puntaje de la pregunta : " + prueba.get(seleccionar[i]).puntaje);

        }


    }

}
